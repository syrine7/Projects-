
package location_automobile;

public class Location_automobile {

   
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
